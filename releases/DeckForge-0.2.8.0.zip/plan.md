# DeckForge Implementation Plan

> **For Hermes:** Execute task-by-task, keep the HTML self-contained, and do not report completion before the browser and engine proofs are green.

**Goal:** Build an offline, single-file iPhone/iPad card-game app with a physically simulated deck/shoe, playable Blackjack and 2–4-seat Durak, configurable 2–4-seat Mau-Mau variants, persistent bankroll/progression, and a $100 bankruptcy grant.

**Architecture:** `deckforge.html` is the only runtime artifact and contains all CSS and JavaScript inline. The engine is separated into small classes/functions inside the script (`Deck`, `Shoe`, `BlackjackGame`, `DurakGame`, `MauMauGame`, `Bankroll`, `Progression`, persistence, UI). Every draw removes a concrete card object from a shuffled array; no game asks RNG for a fresh rank/suit during play. `window.DeckForge` exposes the engines and deterministic self-tests for browser proofs without adding runtime dependencies.

**Tech Stack:** HTML5, CSS, vanilla ES modules-style code in one inline script, CSS playing cards, `localStorage`, `crypto.getRandomValues` with injectable seeded RNG for tests. No CDN, fonts, images, build step, or network dependency.

---

## Requirements ledger

| Requirement | Implementation | Acceptance proof |
|---|---|---|
| One offline single file | `deckforge.html`; inline CSS/JS only | no external `<script>`, `<link>`, image or network request; `node --check` passes |
| Genuine deck simulation | Fisher–Yates shuffle once; card objects are removed from `cards` by `draw`; discard/talon state is explicit | deck count decreases, drawn IDs never repeat, audit reports every card in exactly one zone |
| Blackjack | six-deck shoe, hit, stand, double, split, insurance, blackjack 3:2, dealer soft-17 policy, push/bust/payouts | direct engine tests plus a browser hand from deal through settlement |
|| Durak | configurable 2–4-seat Podkidnoy match with 24/36/52-card decks, trump, attacks, throw-in/transfer | legal-move matrix, multi-seat stress and full browser match |
|| Mau-Mau | physical 32/36/52/64-card packs; 2–4 seats; common and regional variants, scoring, calls, Idioten-Mau | deterministic rule tests, bounded AI, rendered play/settlement, physical-card audit |
|| Currency | persistent dollars, wager deductions, payouts, mode stakes, visible transaction log | balance before/after assertions, reload persistence, no negative balance |
| Bankruptcy | exactly +$100 when balance reaches zero and user attempts a new wager/match | engine and UI test at `$0` verifies one grant and no repeated grants before spending |
|| Progression | separate unlock tracks for Blackjack, Durak, and Mau-Mau with increasing modes/stakes | locked mode cannot start; wins unlock exact next mode; UI reflects progress |
| iPhone/iPad UX | safe-area layout, large buttons, responsive table, touch-action, CSS cards, no horizontal overflow | 390×844 and 1024×768 geometry/overflow checks; real touch-dispatch on action buttons |
| Evidence | plan, test report, screenshots and measured browser output kept in project | `proofs/` contains JSON/report and unique screenshots; final response cites measured numbers |

## Rules fixed before implementation

- Blackjack uses six standard 52-card decks (312 cards) per shoe. Cards have unique `shoeId`/`serial`, even when rank and suit repeat. The shoe reshuffles only at a defined penetration threshold, never between individual draws.
- Blackjack dealer stands on soft 17. Natural Blackjack pays 3:2; a split 21 is not natural. Double-down is allowed on the first two cards of each hand; split hands may double. Insurance is available only against an Ace up-card and pays 2:1. One split is allowed initially, with aces receiving one card only.
- Durak uses the 36-card ranks 6 through Ace, 2–4 seats, one trump suit, a maximum of six cards in an attack, and standard Podkidnoy throw-in rules. The defender may beat an attack card or take the complete table. After a successful defense the defender attacks next; after a take, the same attacker attacks again. Drawing after each round is attacker first, then defender, up to six cards.
- A match stake is deducted when it begins. Blackjack results pay according to hand rules. In Durak, the first finisher receives `configured players × stake`; any later finisher before the Durak receives only their own ante back; the last Durak loses their ante; draws/stalemates return the human stake. Mau-Mau match winners collect the table pot. A new wager at balance 0 grants exactly $100 first. Balance is never allowed below zero.
- Modes are intentionally simple and visible: four Blackjack, four Durak, and four Mau-Mau tables. Each next mode requires wins in that game and has a higher minimum stake. No hidden debug unlock is shipped.

---

## Phase 1: project shell and visual system

### Task 1: Create the project and plan checkpoint

**Files:**
- Create: `~/Documents/DeckForge/deckforge.html`
- Create: `~/Documents/DeckForge/plan.md` (copy of this plan)
- Create: `~/Documents/DeckForge/.hermes/plans/2026-11-23_172723-deckforge.md`
- Create: `~/Documents/DeckForge/proofs/.gitkeep`

**Acceptance:** project directory exists, the two plan copies are identical, and the runtime file remains absent until the implementation task starts.

### Task 2: Build the responsive shell

**Files:** `deckforge.html`

Add the viewport/meta tags, exact unified dark `:root` palette, sticky header, game tabs, bankroll pill, home screen, game screen, mode cards, felt/table region, action dock, modal/toast layer, and a compact diagnostics panel. Use `<button>` for every interactive action, `touch-action: manipulation`, `env(safe-area-inset-bottom)`, and no inline `onclick` handlers.

**Acceptance:** fresh page renders the home screen at desktop and mobile widths; all declared IDs exist; no overflow at 390×844.

### Task 3: Add card and chip rendering primitives

**Files:** `deckforge.html`

Implement DOM renderers for a card (`rank`, `suit`, `face-down`, selected, disabled), hand fan/grid, chip buttons, badges, and deck audit summary. Add accessible labels and stable `data-testid` attributes.

**Acceptance:** card renderer produces the four suits, red/black colors, face-down state, selection state, and responsive card sizes without layout breakage.

---

## Phase 2: engine-first implementation (TDD order)

### Task 4: Implement random sources and physical decks

**Files:** `deckforge.html`

Implement `RandomSource.crypto()`, `RandomSource.seeded(seed)`, Fisher–Yates, `Card`, `Deck`, `Shoe`, `draw`, `peek`, `discard`, `remaining`, `snapshot`, and `audit`. Use immutable card identity and an explicit zone map. Make the test suite injectable with a deterministic source while production uses crypto randomness.

**Tests:**
- 52-card standard deck has one card for each rank/suit.
- Six-deck shoe has 312 distinct serials and 24 copies per rank/suit.
- A shuffle changes order for a known seed but preserves the multiset.
- `draw(n)` removes exactly `n`, returned serials never recur, and `remaining` decreases.
- Audit catches a deliberately duplicated/missing card.

**Acceptance:** all deck tests pass and a real game state can expose the exact remaining count.

### Task 5: Implement bankroll, transactions, persistence, and progression

**Files:** `deckforge.html`

Implement `Bankroll` with `balance`, `ensureFunds(amount)`, `debit`, `credit`, `grantBankruptcy`, and capped transaction history. Implement separate progression tracks, mode definitions, unlock rules, save/load schema versioning, reset-to-default, and corrupt-save recovery.

**Tests:**
- Debit rejects a wager larger than balance and never produces a negative balance.
- `$0` + new wager grants `$100` exactly once, then debits the wager.
- Blackjack/Durak payouts match their fixed result rules.
- Wins unlock only the next configured mode; locked modes reject start.
- Save/load round-trip preserves balance, wins, unlocks, and transaction history.

**Acceptance:** persistence works after reload and all economy values are visible in UI.

### Task 6: Implement Blackjack state machine

**Files:** `deckforge.html`

Implement shoe setup, wagers, initial deal, dealer hole card, action validation, hit, stand, double, split, insurance, dealer resolution, hand status, natural detection, exact payout settlement, discard, round reset, and shoe reshuffle threshold. Keep the engine UI-independent.

**Tests:**
- Ace total calculation handles soft/hard totals and bust correctly.
- Natural Blackjack pays 3:2; dealer natural pushes a player natural; ordinary 21 is not natural after split.
- Hit/stand/double validation rejects illegal actions; double debits the extra stake.
- Split creates two hands, moves one physical card, and applies the ace restriction.
- Dealer draws to 17 and stops on soft 17.
- Insurance is offered only against Ace and resolves at 2:1.
- All settlement paths conserve money and move used cards to discard.
- A seeded shoe produces the expected exact physical serial sequence.

**Acceptance:** engine can complete every legal action path without UI state leaking into rule logic.

### Task 7: Implement Durak state machine and AI

**Files:** `deckforge.html`

Implement the 36-card deal, trump, lowest-trump opening attacker, table attack objects, rank matching, beat rules, legal throw-in calculation, take, end-attack, draw order, next-attacker rules, terminal win/loss, and a deterministic heuristic AI. AI must never make an illegal move; it must choose the cheapest legal defense or take when none exists.

**Tests:**
- Deal gives six cards per player and a valid trump card/talon.
- Every beat combination (same-suit higher, trump over non-trump, trump-on-trump, off-suit non-trump) is correct.
- Throw-in only accepts ranks already on the table and respects hand/attack limits.
- Take transfers every table card to the defender and preserves card identity.
- Successful defense discards table cards and changes the attacker.
- Drawing occurs attacker first, then defender, never above six.
- AI action sequences remain legal until the match ends.
- Empty hand plus empty talon ends the game with the correct winner.
- Zone audit confirms all 36 cards are accounted for after every tested round.

**Acceptance:** a full AI-vs-AI seeded match terminates, and a player-controlled match can reach both win and loss outcomes.

---

## Phase 3: UI integration and complete playability

### Task 8: Wire home, modes, bankroll, and reset flows

**Files:** `deckforge.html`

Connect game selection, mode selection, bet/stake controls, start buttons, bankruptcy grant messaging, progression display, transaction history, save/reset, and game-over return actions. Keep the selected game/mode in URL-free local state and update all visible values after every mutation.

**Acceptance:** a user can start any of the three games from a fresh page, cannot start a locked mode, and can reset a save without stale UI.

### Task 9: Wire Blackjack controls and table

**Files:** `deckforge.html`

Render dealer/player hands, hidden dealer card, shoe count, current wager, totals (including soft/hard indicator), action buttons, split hands, insurance panel, outcome banner, and next-round control. Disable buttons from engine legality rather than duplicating rule conditions in event handlers.

**Acceptance:** real touch/click flow: choose Blackjack → choose mode → place wager → Deal → Hit/Double/Split/Insurance where legal → Stand → dealer resolves → bankroll/progression updates → next hand.

### Task 10: Wire Durak controls and table

**Files:** `deckforge.html`

Render trump, talon count, player/AI hands, attack cards and target slots, selection state, contextual action buttons (`Attack`, `Throw In`, `Beat`, `Take`, `End Attack`), turn/status text, action log, and match result. AI turns use a short UI delay but remain deterministic through the injected engine.

**Acceptance:** real touch flow can attack, throw in, beat, take, finish a defense, draw, and reach a win or loss. No action button appears enabled when its engine action is illegal.

### Task 11: Add audio-safe microfeedback and mobile polish

**Files:** `deckforge.html`

Add optional synthesized tap/deal/win/loss cues created only in a user gesture, mute toggle persisted locally, card motion classes, focus states, safe-area dock spacing, landscape/iPad layout, and reduced-motion support. No external audio assets.

**Acceptance:** every audio path is exception-safe when unavailable; mute state persists; buttons remain at least 44px high; reduced-motion removes transitions.

---

## Phase 4: proof, repair, and packaging

### Task 12: Add in-app self-test runner and proof export

**Files:** `deckforge.html`, `proofs/` generated outputs

Expose `window.DeckForge.runSelfTests()` and a Diagnostics modal that reports grouped assertions, pass/fail counts, and engine invariants. Include a proof export that serializes the latest test result and current deck audit without changing gameplay data.

**Acceptance:** self-tests run from a fresh page, report zero failures, and include counts for deck, Blackjack, Durak, economy, progression, persistence, and UI helpers.

### Task 13: Static and syntax audit

**Commands:**
```bash
python3 - <<'PY'
import re
from pathlib import Path
html=Path('deckforge.html').read_text()
scripts=re.findall(r'<script[^>]*>(.*?)</script>', html, re.S)
Path('/tmp/deckforge-check.js').write_text('\n'.join(scripts))
print('scripts:', len(scripts), 'external:', bool(re.search(r'<(?:script|link)[^>]+(?:src|href)=', html)))
PY
node --check /tmp/deckforge-check.js
```

Also compare every `getElementById('...')` with an HTML `id`, check no external URLs/assets, check duplicate IDs, and inspect all buttons for listeners.

**Acceptance:** syntax passes, no missing IDs, no duplicate IDs, and the runtime has no external dependency.

### Task 14: Browser live QA and mobile geometry

Use Browser Use on a fresh `file://` page.

- Install error/unhandled-rejection hooks before interaction.
- Test home → Blackjack → deal → action → settlement.
- Test home → Durak → attack/defense/take/draw until terminal result.
- Run `DeckForge.runSelfTests()` in the browser and read back the result.
- Set 390×844 DPR 2 and 1024×768, reload in the same tab, assert no horizontal overflow, action dock inside viewport, and all visible buttons have usable rects.
- Dispatch real touch events to primary action buttons and verify state changes from engine/UI state, not just `click()`.
- Capture unique screenshots for home, Blackjack table, Durak table, diagnostics/test report, and a mobile viewport.

**Acceptance:** zero page errors, all named flows reach visible state changes, no mobile overflow, self-test failures = 0.

### Task 15: Final evidence and handoff

**Files:**
- Create: `proofs/self-test.json`
- Create: `proofs/browser-qa.json`
- Create: `proofs/static-audit.txt`
- Create: `proofs/home.png`, `proofs/blackjack.png`, `proofs/durak.png`, `proofs/mobile.png`
- Update: `plan.md` with measured verification and remaining limits

Record actual counts and measurements only: engine assertion total, browser errors, deck audit status, Blackjack/Durak terminal runs, balance transitions, mobile dimensions/overflow, and screenshot paths. If a physical iPhone/iPad or audio hardware was not available, state that explicitly instead of implying it was tested.

**Acceptance:** the final report points to real files and tool output; no fabricated proof numbers.

---

## Risks and tradeoffs

- Full split/insurance support increases Blackjack edge cases; the engine tests are mandatory before styling is considered complete.
- Durak is a state-heavy ruleset. The UI will use contextual controls over a stable engine rather than duplicating legality logic in the DOM layer.
- Browser automation can prove mobile geometry and touch dispatch but cannot replace a physical iPhone/iPad check; the final report will separate Chromium emulation from real-device validation.
- `localStorage` is intentionally local-only. There is no account, cloud save, or multiplayer networking in this offline first version.
- The app is a playable first release, not a casino-money product: currency is fictional and no payment or gambling integration exists.

## Definition of done

1. `deckforge.html` opens offline and has no external dependencies.
2. Both games can be started and completed through the UI, including player win/loss paths.
3. Physical deck/shoe audits pass and no card is generated ad hoc during play.
4. Bankroll, payouts, bankruptcy grant, progression, and persistence are tested.
5. Static checks, engine self-tests, browser flows, touch probes, and mobile geometry checks pass.
6. Plan and proof artifacts contain measured results and clearly list anything not tested on real hardware.

## Verification evidence (actual run)

- Runtime artifact: `deckforge.html` — 97,967 bytes, 1,071 lines, one inline script, no external assets or network dependency.
- Static audit: `node --check` passed; no duplicate IDs, no missing `$()` DOM references, no inline event attributes, and `crypto.getRandomValues` plus physical `this.cards.pop()` draw are present.
- Engine diagnostics: **26 passed / 0 failed**. Groups: physical shoe 5/5, bankroll/progression 4/4, Blackjack 8/8, Durak 7/7, persistence/UI helpers 2/2.
- Browser Blackjack: real lobby → deal → rendered action flow reached `settled`; the six-deck shoe reported 308 cards after the four-card deal and no page errors.
- Browser persistence/economy: a $10 start changed `$250 → $240` and the same `$240` survived reload; a zero-balance start visibly granted `$100`, debited the `$10` stake, and left `$90` with one grant.
- Browser Durak: real rendered-card/action flow reached `finished`; recorded player losses, a player win, and a draw across seeded-independent UI matches. The engine also completed bounded autonomous matches with physical-card audits on every step.
- Mode selection proof: desktop strip center `512` at 1024px with four 230px cards; mobile strip center `195` at 390px with two centered columns.
- Evidence files: `proofs/self-test.json`, `proofs/browser-qa.json`, `proofs/static-audit.txt`, `proofs/home.png`, `proofs/blackjack.png`, `proofs/durak.png`, `proofs/diagnostics.png`, `proofs/mobile.png`, `proofs/mode-selection.png`.
- Release artifacts: `VERSION` (`0.1.0`), `RELEASE_NOTES_0.1.0.md`, `README.md`, and the release archive are prepared after the final verification gate.
- Not tested: physical iPhone/iPad Safari hardware and real audio output. Chromium mobile emulation and touch-pointer dispatch were tested; currency is fictional and local-only.

### Nachtrag v0.1.0

- **Symptom:** The table-mode cards used the full lobby width instead of reading as a centered mode chooser.
- **Cause:** `.mode-strip` used a four-column full-width grid with no centered group width.
- **Change:** Replaced it with a centered, capped flex strip on desktop and a centered two-column grid on mobile; centered the mode heading and kept each desktop mode card at 230px.
- **Before/after proof:** final desktop strip center `512` at viewport `1024`, four cards at `230px`; final mobile strip center `195` at viewport `390`, four cards in two centered columns; browser self-tests were `26/26` at that release checkpoint.

### Lokaler Polish-Pass nach 0.1.0 (nicht als neuer Release getaggt)

- **Blackjack-Spielgefühl:** Dealer-Natural/Dealer-21 hat eine eigene Outcome-Karte statt generischem `Hand lost`; die doppelte Settlement-Meldung ist entfernt; Spielertotals bleiben auch im Live-State korrekt; `Deal next hand` startet Runde 2 direkt im Tisch und führt nicht mehr ins Hauptmenü.
- **Viewport-Fix:** Gameplay nutzt eine feste `100dvh`-Fläche mit In-Flow-Action-Dock. Final gemessen: `390×844 → scrollWidth 390 / scrollHeight 844`, `1024×768 → scrollWidth 1024 / scrollHeight 768` für Blackjack und Durak.
- **Durak Touch:** Player cards haben echte Pointer-Drag-Hooks, Drop-Zonen für Tisch und Angriffsziele, Ghost-Card, Highlighting und Trump-Karten mit Goldrahmen/Kronenmarkierung. Angriff und Verteidigung wurden über `PointerEvent` mit `pointerType=touch` durchgespielt; beide Pfade blieben legal und fehlerfrei.
- **Visual pass:** Home-CTA und 3-D-Kartenstapel, polierte Kartenflächen, klare Outcome-Karte, kompaktes iPhone-Durak-Layout und sichere Dock-Abstände. Screenshots: `proofs/polish-home-mobile.png`, `proofs/polish-blackjack-dealer21-mobile.png`, `proofs/polish-durak-drag-mobile.png`, `proofs/polish-diagnostics-mobile.png`.
- **Finale Beweise:** `29/29` Engine-Assertions, Static Audit PASS, keine Page Errors, `$250 → $240` über Reload persistent, Bankruptcy `$0 → $100 → $90` mit exakt einem Grant. Vollständige Messwerte: `proofs/polish-qa.json`.
- **Grenzen:** Physisches iPhone/iPad-Safari und echtes Audio wurden nicht getestet. Der Harness konnte keinen CDP-Hardware-Touch-Dispatch ausführen; deshalb ist der Drag-Nachweis ein echter gerenderter PointerEvent-Pfad mit Touch-Pointer, kein physischer Safari-Test. `VERSION`, Release-Archiv und Tag bleiben unverändert bei `0.1.0`.

### Follow-up: Header, Card-Rows und Reaktionspacing

- **Top-Bar:** Die Spielauswahl ist jetzt eine echte mittlere Grid-Spalte. Mobile Tabs werden auf `⌂ / BJ / DU` kompakt, aber vollständig dargestellt; gemessene Zentrierung: `390px → center 195px`, `1024px → center 512px`, jeweils innerhalb ≤ `0.01px`.
- **Blackjack-Cards:** Card rows sind nicht mehr horizontal scrollbar. Sie nutzen `overflow: visible` und `flex-wrap: wrap`; finaler DOM-Nachweis bei `390×844`: `scrollWidth === clientWidth === 328`, keine Scrollbar.
- **Reaktionszeit:** Dealer-Settlement zeigt zuerst einen statischen `Dealer is checking the hand…`-Zustand und wartet zufällig `320–760ms`; Durak-AI nutzt denselben Bereich zwischen Zügen. Nachweis: ein echter Durak-AI-Timer mit `415ms`, anschließend `turn:0`, `phase:defense`, keine Fehler. Keine neue Animation hinzugefügt.
- **Follow-up-QA:** `29/29`, `node --check PASS`, keine DOM-/Runtimefehler, Persistence und Bankruptcy erneut grün. Aktuelle Messwerte und Screenshots: `proofs/polish-qa.json` plus fünf `polish-*.png`-Beweise.
- **Release-Grenze:** Kein Version-Bump, kein Commit, kein neues Archiv und kein Tag.

### Multiplayer und Table-Varianten umgesetzt

- **Lobby-Konfiguration:** Beide Spiele haben eine sichtbare `Table setup`-Karte. Blackjack: `1–4 seats`, Natural `3:2/6:5`, Soft-17 `Stand/Hit`, Insurance und Surrender. Durak: `2–4 seats`, `All players/Neighbors` beim Einwerfen und `Push allowed/off`.
- **Blackjack:** Ein menschlicher Sitz plus AI-Sitze werden physisch aus demselben Shoe gedealt. AI-Sitze spielen vor dem menschlichen Zug; Settlement bewertet alle vier Sitze, aber nur Sitz 0 verändert die Bankroll. 6:5, Soft-17, Insurance und Surrender sind Engine-Regeln, nicht nur UI-Texte.
- **Durak:** 2–4 Sitze, zirkuläre Sitznachbarn, Nachbar-only/all throw-in, optionales gleichrangiges Weiter-Schieben und AI-Turn-Progression. Vier-Sitz-Autoplay endet nach `54` Schritten mit gültigem Audit.
- **Live-UI:** Aktiver Tisch zeigt die Konfiguration im Header/Table-Badge, kompakte AI-Sitz-Lanes, menschliche Hand und variantenspezifische Actions. Gegnerkarten werden in Durak mobil als Kartenrücken plus Kartenanzahl dargestellt; die menschliche Hand nutzt eine lesbare Fan-Anordnung mit Scroll-Fallback, damit Tisch/Hand bei `390×844` sichtbar bleiben.
- **Finale Beweise:** `39/39` Assertions, Static Audit PASS, 4-seat Blackjack `participants:4/results:4/audit:true`, 4-seat Durak `finished/steps:54/audit:true`, 2-seat Push `attacker:1/defender:0/audit:true`, 4-seat-only All-player throw-in, Throw-in Off, every table setting has an English help button, redesigned felt/card-room home preview, Konfigurations-Reload persistent, Drag-Angriff weiterhin `table:1/hand:5/phase:defense`, keine Browserfehler. Vollständige Daten: `proofs/multiplayer-variants-qa.json`.
- **Release status:** `VERSION` is `0.2.3`; the user explicitly requested the commit, tag, public GitHub repository, and Pages deployment after the final verification gate.

### Blackjack single-hand outcome fix

- **Symptom:** A completed one-hand Blackjack round showed the same outcome banner twice.
- **Cause:** `renderBlackjack()` rendered a per-hand outcome and the overall settlement banner for the same single hand.
- **Change:** Keep per-hand banners for split hands; use only the overall settlement banner for a single hand.
- **Before/after proof:** At `390×844`, a real deal/stand/settle flow changed `.outcome-banner` count from `2` to `1`; action buttons remained visible, document size stayed `390×844`, browser errors `0`, diagnostics `39/39`, `node --check` PASS.
- **Release:** After the fix commit, the user approved release `0.2.3`; `VERSION`, `RELEASE_NOTES_0.2.3.md`, tag `v0.2.3`, and `releases/DeckForge-0.2.3.zip` are the release artifacts.

### Blackjack split/double repair — 0.2.4

- **Baseline defect:** In v0.2.3, seed `52` left a doubled split hand at `stood=false`, `canAct=true`, `activeIndex=0`; Hit/Stand remained available and Hand 2 never became active.
- **Engine fix:** Double now draws exactly one physical card, marks that hand closed, and advances to the next playable split hand or settles the round. Added tests for below-21 double, illegal post-double actions, split hand advancement, split Aces, split 21 payout, and the one-split rule.
- **UI fix:** Split hands carry explicit `YOUR TURN`, `UP NEXT`, `DOUBLED`, `STOOD`, `WON`, `LOST`, or `PUSH` badges; the active hand is highlighted and the action prompt names its hand. Mobile stacks hands with compact per-hand net badges; tablet uses two columns. Settlement keeps one aggregate banner.
- **Final verification:** 44/44 diagnostics; `node --check` PASS; static audit `171507` bytes / `1589` lines, zero external assets, duplicate IDs, missing DOM references, inline handlers, and browser errors. Browser QA passed solo double and split→double→Hand 2→settlement at `390×844`, 4-seat split at `390×844`, and tablet split at `1024×768`; no clipping or document overflow.
- **Evidence:** `proofs/blackjack-split-double-qa.json` plus mobile, multi-seat, and tablet screenshots.
- **Release:** `VERSION` / `APP_VERSION` `0.2.4`; notes `RELEASE_NOTES_0.2.4.md`; archive `releases/DeckForge-0.2.4.zip`; tag `v0.2.4`.

### DeckForge 0.2.5 — multiplayer correctness, Durak feel, visible version

- **Blackjack:** Fixed the multi-seat scheduler handoff after either insurance choice. Fresh UI runs passed for 3-seat Take/No-thanks and a 4-seat table through all three AI turns, a human action, settlement, and shoe audit.
- **Durak rules:** Corrected clockwise attacker/defender transitions after defense, take and push; refill order; empty-seat handling; end-of-match Durak/draw outcomes; and one-pass-per-bout throw-in tracking. The latter prevents `all players` from ping-ponging forever among seats with no matching rank. Empty AI turns now advance, and any remaining no-op is surfaced as a paused state instead of a repeated timer.
- **Durak UI:** Human hand display sorts by suit/rank with trumps last without mutating the engine hand. Table cards, red suits, compact trump/talon, defense target and drop highlight were improved. The exposed trump is no longer duplicated after the talon is empty.
- **Visible release version:** Header badge and accessible brand label show `v0.2.5` on home and live Blackjack/Durak screens, including 390px mobile width.
- **Engine evidence:** `proofs/self-test.json` records 60/60 assertions. `proofs/browser-qa.json` records 100 autonomous matches across five 2–4-seat variants, full rendered-UI matches for 2/3/4 seats, insurance paths, drag/drop behavior, reaction measurements and viewport geometry.
- **Timing evidence:** UI action-to-first-AI callback measured 328ms (low), 546/547ms (mid) and 775ms (high including browser/timer dispatch overhead); scheduled delay remains 320–760ms.
- **Responsive evidence:** At 390×844 and 1024×768, six-pair Durak fixtures had no document overflow and every action control stayed within the viewport.
- **Limits:** Physical iPhone/iPad Safari and real audio were not tested. CDP hardware-touch dispatch timed out; synthetic `PointerEvent` touch-pointer handlers were exercised. QA browser contexts were isolated; no test bankroll or active game is included in repository artifacts.
- **Release artifacts:** `VERSION` / `APP_VERSION` `0.2.5`; notes `RELEASE_NOTES_0.2.5.md`; archive `releases/DeckForge-0.2.5.zip`; annotated tag `v0.2.5`. The Pages workflow deploys the release tag.

### DeckForge 0.2.6 — Durak landscape, queued throw-ins, and next-round stake

- **Durak action dock:** Compact landscape layout covers six attack pairs and 2–4 seats. Final Chromium geometry: `390×844`, `1024×768`, `1024×600`, `1194×834`, `1194×700`, `1366×768`, `1366×600`; all buttons/dock inside the viewport, hand above dock, document dimensions equal the viewport. Full measurements: `proofs/durak-0.2.6-layout.json`.
- **AI reaction / pile targeting:** Human can select a matching card and a specific covered target while an eligible AI acts, queue it without changing turn or hand, cancel/continue, and execute only on the human turn. A valid touch-pointer drag queues the selected pile. Stale targets clear safely. Details: `proofs/durak-0.2.6-throw-in-qa.json`.
- **Optional push:** `Push onward` appears enabled before a card is selected when legal; defense, push, and take remain separate actions. Proof: `proofs/durak-0.2.6-push-qa.json`.
- **Next-round stake:** Blackjack and Durak result screens offer table-bounded next-stake presets beside the rematch action. Browser QA starts both next rounds at `$20` and confirms a finished Durak result remains `$10` after changing the next wager. Proof: `proofs/durak-0.2.6-next-wager-qa.json` and `proofs/durak-0.2.6-next-wager-layout.json`.
- **Endgame safety:** Seed `261201` previously repeated a complete four-seat `all players`, no-push position. It now resolves at step `77` as a visible stalemate draw, returns the `$10` wager exactly, and preserves the 36-card audit. Proof: `proofs/durak-0.2.6-stalemate.json`.
- **Final tests:** 69/69 in-app assertions; 168 seeded autonomous matches across 14 valid 2–4-seat policy/push combinations, all audited each action and terminal-checked; complete rendered-UI matches for 2/3/4 seats; Blackjack deal/stand/settlement/next-wager flow; `node --check` PASS; static audit PASS (`230717` bytes, `1915` lines, one inline script, no external refs/duplicate IDs/missing DOM refs/inline handlers); `git diff --check` PASS.
- **AI timing:** scheduled planning window `1400–2200ms`, normal/queued response `320–760ms`; observed callback examples `1651ms`, `2585ms`, `2293ms`, and queued `1345ms` including headless timer jitter. Continue AI and the 12-second timeout both resumed correctly. Proof: `proofs/durak-0.2.6-ai-timing.json`.
- **Visible version and screenshots:** header shows `v0.2.6` on home, Blackjack, and Durak; screenshot proofs are `proofs/deckforge-0.2.6-*.png`.
- **Limits:** physical iPad Safari and real audio were not tested. Chromium device emulation and synthetic touch-pointer events were tested.
- **Release artifacts:** `VERSION` / `APP_VERSION` `0.2.6`; notes `RELEASE_NOTES_0.2.6.md`; archive `releases/DeckForge-0.2.6.zip`; annotated tag `v0.2.6`. The final handoff records the commit SHA and verified remote deployment.

### DeckForge 0.2.6.1 — Durak hand sizing, batch attacks, and all-seat pot

- **Hand layout:** Six-card Durak hands use small whole cards with visible gaps; larger hands scroll rather than overlap. Vision and DOM checks passed at iPhone-emulated `390×844` (DPR3) and iPad-landscape-emulated `1194×834` (DPR2).
- **Multi-card attacks:** Tap same-rank cards to add/remove a batch, then attack together. Batches also work by dragging a selected card onto the table. Targeted throw-in batches insert beside the selected covered pile, preserve links, and pass the 36-card audit. Single-card actions remain available.
- **Push drag:** The enabled `Push onward` button is a real drop target with a high-contrast amber hover state. Tap and drag paths both transferred a legal card and preserved the 36-card audit.
- **Pot settlement:** The Durak winner receives `players × stake`; loss forfeits only the human ante and draw/stalemate refunds it. A four-seat `$10` winner was settled through the rendered action: `$40` credited, `$30` net, `$280` bankroll header after starting at `$250` and deducting the ante.
- **Final tests:** 75/75 in-app assertions; 168/168 seeded matches across 14 2–4-seat configurations with a card audit on every move; a real two-seat lobby-to-settlement browser flow; queue/continue/timeout and batch/tap/drag UI paths; no browser errors.
- **Layout matrix:** `390×844`, `1024×768`, `1024×600`, `1194×834`, `1194×700`, `1366×768`, `1366×600`; every hand/dock stayed within its bounds, no card overlap/clipping, document equals viewport. Evidence: `proofs/durak-0.2.6.1-layout.json`.
- **Vision proofs:** iPhone, iPad, Push onward drop highlight, and four-seat payout screenshots are in `proofs/deckforge-0.2.6.1-*.png`; structured results are in `proofs/browser-qa-0.2.6.1.json`.
- **Limits:** Physical iPhone/iPad Safari and real audio hardware were not tested; checks used Chromium emulation and synthetic touch-pointer dispatch.
- **Release artifacts:** `VERSION` / `APP_VERSION` `0.2.6.1`; notes `RELEASE_NOTES_0.2.6.1.md`; archive `releases/DeckForge-0.2.6.1.zip`; annotated tag `v0.2.6.1`. Acceptance: read back the published tag/asset, Pages deploy/build, live runtime bytes/version, and clean worktree.

### DeckForge 0.2.6.2 — short-phone Durak/Blackjack and settlement polish

- **Baseline:** User’s 3-seat iPhone Durak screenshot clipped the human cards beneath the dock. The existing browser reproduction at `375×667` had the hand box at `y=438..539` and dock starting at `y=496` (43px overlap). Three-seat Blackjack also overflowed its compact table.
- **Durak layout:** Short phones use two-column opponent status, a slim trump/talon strip, a flexible table, six readable hand cards, and one-row Beat / Push / Take actions. At `375×667`, the hand ends at `y=611` and the dock starts at `y=614`; at `375×600` four seats, all six cards and all actions remain visible. The drag ghost now floats above the Push label, leaving it readable.
- **Blackjack layout:** Short screens compact the header, dealer/AI/player zones, and controls. AI mini-cards use readable 8px overlap and stay in one row; the table zones use balanced spacing. The AI/insurance action dock is hidden when no player action is available. Settlement uses a full-width next-wager row and two full-width rematch actions. A `390×844` flex-shrink defect was fixed so dealer/player panels and AI rows no longer clip.
- **Terminal clarity:** A finished Durak match now displays `Match complete` instead of the stale `Open attack` prompt; the empty talon card placeholder is omitted while the `0 cards left` count remains.
- **Diagnostics:** `75/75` in-app assertions passed. Durak stress passed `168/168` seeded matches across 14 valid 2–4-seat throw-in/push variants, with card audits on every action and legal terminal results.
- **Layout matrix:** All 11 final cases passed with no document overflow, clipping, hidden controls, or failed deck audits: 3-seat Durak at `375×667`, `390×844`, and iPad `1194×834`; 4-seat Durak at `375×600`; 3-seat Blackjack insurance/player at `375×667` and `390×844`; 4-seat Blackjack player at `375×600` and `390×844`; 3-seat Blackjack player at `1194×834`. Geometry and screenshots: `proofs/browser-qa-0.2.6.2-layouts.json` and `proofs/deckforge-0.2.6.2-*.png`.
- **Rendered flows:** Fresh 3-seat Blackjack lobby → deal → Stand → settlement passed at `375×667`; the final example pushed and returned `$10` with `$250` unchanged. A fresh 3-seat Durak lobby → legal rendered actions → match result finished at round 22 with audit true and zero browser errors. Push onward worked by tap and touch-pointer drag; each transfer increased the table from one card to two, reduced the hand from six to five, and preserved the physical-card audit.
- **Vision:** Reviewed the iPhone `375×667` / `390×844` layouts and iPad-landscape `1194×834` layouts for both games, Blackjack insurance/player/settlement, Durak terminal result, and the highlighted Push drop target. Vision confirmed all hands and controls visible; the drag label stays unobscured.
- **Static checks:** `node --check`, JSON parsing, static audit (`263200` bytes, `2001` lines, one inline script, zero external assets/URLs, duplicate IDs, missing DOM references, and inline event attributes), and `git diff --check` passed.
- **Limits:** Physical iPhone/iPad Safari and hardware audio were not tested; layout used Chromium emulation and drag integration used synthetic touch `PointerEvent`s. Release publication/Pages read-back is recorded in the final handoff.
- **Release artifacts:** `VERSION` / `APP_VERSION` `0.2.6.2`; notes `RELEASE_NOTES_0.2.6.2.md`; archive `releases/DeckForge-0.2.6.2.zip`; tag `v0.2.6.2`. Post-publish read-back gate: verify the tag/asset, Pages deploy/build, public runtime bytes/version, and clean worktree before handoff.

### DeckForge 0.2.6.3 — mobile setup progressive disclosure

- **Requested version:** The clarification was to increment the final component of `0.2.6.2` by one, yielding `0.2.6.3`; tag `v0.2.6.3`. The earlier mistaken `v0.0.0.1` publication is superseded and retained for history.
- **Mobile:** At widths `≤760px`, start both game lobbies with table settings collapsed behind `Customize`. Keep a concise selected-rules summary visible; leave wager and primary start controls outside the hidden settings panel. At `390×844`, wager/start stay above the fold; at `375×667`, vertical scroll remains but there is no horizontal overflow.
- **Interaction:** Customize exposes all seat/rule options. Changing seats/rules preserves the open state; Hide closes it; Home/re-enter restores mobile collapse. With no explicit override, resizing to desktop opens the settings, and resizing back to mobile closes them.
- **Desktop:** `1024×768` lobby defaults to expanded settings and can still collapse.
- **Diagnostics/stress:** `76/76` in-app assertions; Durak stress `168/168` seeded matches across 14 2–4-seat throw-in/push variants; zero failures and browser errors.
- **Rendered flows:** 3-seat Blackjack → deal → Stand → settled payout; 4-seat Durak/all-player → legal Take cards action. Both deck audits passed. `proofs/blackjack-ui-flow-0.2.6.3.json` and `proofs/durak-ui-flow-0.2.6.3.json`.
- **Disclosure/touch:** Customize, settings rerender, Hide, Home/re-entry reset, and auto-resize defaults passed in `proofs/setup-disclosure-0.2.6.3.json`. Synthetic touch-pointer input hit-tested and opened the actual Customize control; physical Safari not tested.
- **Vision:** Collapsed/expanded mobile lobbies reviewed for both games at `390×844`, Blackjack at `375×667`, and expanded desktop Blackjack at `1024×768`. Desktop has no horizontal overflow, but the lower wager/Deal controls are below the fold (document height `1143px`) and require vertical scroll.
- **Static:** `node --check`, static audit (`266305` bytes, `2009` lines, 51 unique IDs, no external assets/URLs, duplicate IDs, missing references, or inline event attributes), JSON validation, and `git diff --check` pass.
- **Release artifacts:** `VERSION` / `APP_VERSION` `0.2.6.3`; notes `RELEASE_NOTES_0.2.6.3.md`; archive `releases/DeckForge-0.2.6.3.zip`; tag `v0.2.6.3`. Verify tag/asset, Pages deployment/build, live runtime bytes, and clean worktree before handoff.

### DeckForge 0.2.6.5 — Blackjack recovery + bankroll analytics

- **Blackjack fix:** `startRound()` now leaves the previous `settled` phase before resolving any new-hand dealer natural. A deterministic fresh UI flow completed round 1, settled round 2 with dealer `10♣ A♣` against player `4♠ 4♥`, rendered exactly one Dealer Blackjack outcome, then started playable round 3. Both physical-card audits passed; zero runtime errors. Evidence: `proofs/blackjack-reentry-0.2.6.5.json` and `proofs/deckforge-0.2.6.5-iphone-390-blackjack-round2-natural.png`.
- **Bankroll:** Modern offline dashboard shows balance, game wins, grants, income vs expenses, net flow, balance trend with an explicit range, opening/closing ledger reconciliation, eight paired category charts, and the latest 12 transactions. Analysis is limited to the latest 80 saved ledger entries and remains deterministic with equal/missing timestamps.
- **Analytics/empty-state tests:** `82/82` in-app assertions, including category mapping, flow totals, every category chart, accessible trend/range labels, the 80-entry cap, equal/missing timestamps, empty history, and second-round dealer natural. A 14-entry synthetic ledger reconciled `$0 + $154 = $154`; empty save reconciled `$250 + $0 = $250` without NaN or horizontal overflow. Evidence: `proofs/self-test-0.2.6.5.json`, `proofs/bankroll-layout-0.2.6.5.json`, `proofs/bankroll-empty-0.2.6.5.json`.
- **Stress:** 168 seeded Durak matches across 14 variants, all actions audited and all matches reached a legal terminal state; 0 failures, 32–73 steps. Proof: `proofs/durak-0.2.6.5-stress.json`.
- **Responsive/Vision:** Chromium DPR1 captures at phone `390×844`, iPad portrait `834×1194`, and iPad landscape `1194×834`; overview/category/recent states reviewed with Vision. No horizontal overflow, clipped chart labels, or overlapping content. Both non-empty and empty histories fit and scroll within the modal.
- **Release badge:** `v0.2.6.5` verified on Home and active Blackjack at `390×844`; proof `proofs/version-badge-0.2.6.5.json`.
- **Static checks:** `deckforge.html` is 295,371 bytes / 2,252 lines with one inline script and 76 literal DOM references; zero missing/duplicate IDs, external assets/URLs, or inline event attributes. `node --check`, JSON/PNG proof validation, and `git diff --check` pass; details: `proofs/static-audit-0.2.6.5.json`.
- **Limits:** Physical iPhone/iPad Safari and audio hardware were not tested; screenshots use Chromium device emulation. Currency remains fictional and local-only.
- **Release artifacts:** `VERSION` / `APP_VERSION` `0.2.6.5`; notes `RELEASE_NOTES_0.2.6.5.md`; archive `releases/DeckForge-0.2.6.5.zip`; tag `v0.2.6.5`. Release tag, asset, Pages build and live runtime-byte match are verified in the final handoff.



### DeckForge 0.2.6.55 — centered DeckForge wordmark

- **Requested version:** Literal target `0.2.6.55`; previous release `v0.2.6.5`. Tag `v0.2.6.55` is new; no prior tags are moved.
- **Header:** Moved a stylized, text-only `DeckForge` button to the horizontal center. Clicking it returns Home from both game shortcuts, lobbies, and active rounds. The redundant Home tab is removed; Blackjack/Durak shortcuts remain at left, bankroll/utilities at right. Version remains beside the game shortcuts; the badge compacts at `320px` but stays visible.
- **Navigation proof:** Rendered coordinate clicks returned Home from Blackjack lobby, Durak lobby, live Blackjack, and live Durak. Card audits remained valid and page errors were zero. Evidence: `proofs/center-brand-0.2.6.55.json` and versioned Home/game screenshots.
- **Geometry:** Wordmark center is within `0.01px` of the content center at `320`, `360`, `375`, `390`, `414`, `834`, `1024`, and `1194px`; no document-width overflow or collisions. The version badge remains visible at every tested width.
- **Tests/Vision:** `83/83` in-app assertions; Vision reviewed phone Home/live Blackjack and iPad portrait Home/live Blackjack plus landscape live Blackjack. No header overlap or clipping. Physical iPhone/iPad Safari was not tested; this was Chromium emulation.
- **Static checks:** `deckforge.html` is 297,225 bytes / 2,262 lines, one inline script, 80 literal DOM refs; no missing/duplicate IDs, external assets/URLs, or inline event attributes. `node --check`, four JSON proofs/nine PNG signatures, and `git diff --check` pass; details: `proofs/static-audit-0.2.6.55.json`.
- **Release artifacts:** `VERSION` / `APP_VERSION` `0.2.6.55`; notes `RELEASE_NOTES_0.2.6.55.md`; archive `releases/DeckForge-0.2.6.55.zip`; tag `v0.2.6.55`. Read back the release asset, Pages build and live runtime bytes before handoff.

### DeckForge 0.2.6.56 — remove game selection from the top bar

- **Correction:** Removed the Blackjack/Durak mode shortcuts from the top bar completely. Header now contains only the left version badge, centered DeckForge Home button, and right-side bankroll/utilities. Game selection stays on the Home cards.
- **Navigation:** Both Home cards still open their respective games. The brand returns Home from both lobbies and active Blackjack/Durak rounds; physical-card audits pass and browser errors are zero. Proof: `proofs/topbar-mode-removal-0.2.6.56.json`.
- **Geometry:** Brand remains centered within `0.01px` at `320`, `360`, `375`, `390`, `414`, `834`, `1024`, and `1194px`; no horizontal overflow or collisions, and the version badge remains visible.
- **Tests/Vision:** `83/83` in-app tests. Vision reviewed phone `320×800`/`390×844` Home, mobile active Blackjack, iPad portrait Home/active Blackjack, and iPad landscape Home; no top-bar mode controls or header collisions. Physical Apple Safari was not tested; this used Chromium emulation.
- **Static checks:** `deckforge.html` is 295,759 bytes / 2,253 lines, one inline script, 78 literal DOM refs; no missing/duplicate IDs, external assets/URLs, or inline event attributes. `node --check`, three proof JSONs/ten PNG signatures, and `git diff --check` pass; details: `proofs/static-audit-0.2.6.56.json`.
- **Release artifacts:** `VERSION` / `APP_VERSION` `0.2.6.56`; notes `RELEASE_NOTES_0.2.6.56.md`; archive `releases/DeckForge-0.2.6.56.zip`; tag `v0.2.6.56`. Verify the release asset, Pages build, live runtime bytes, and clean worktree before handoff.

### DeckForge 0.2.6.6 — Durak deck and optional-rule update

- **Requested version:** Use the exact user-specified `0.2.6.6`. Previous published release remains `v0.2.6.56`; do not move it.
- **Decks:** Select 24 (9–Ace), 36 (6–Ace), or 52 cards (2–Ace), four suits each. Six cards per seat; the supported app range remains 2–4 seats. In a 24-card/four-seat deal the talon is empty and the final dealt card determines trump.
- **Rules:** One exclusive extra-rule selector: Throw-in, Transfer, or Off (neither). Keep Neighbors/All players scope for Throw-in; All players is available only at four seats. Transfer requires matching rank before any cover, the next active defender must have enough cards for the enlarged table, and successive transfers may chain until a cover or capacity limit.
- **Tests:** 89/89 in-app assertions, including exact physical deck/rank counts, 24-card empty-talon trump, setup controls, exclusive normalization and a two-hop physical-card transfer chain.
- **Stress:** 360 seeded matches across 30 configurations (all decks × 2–4 seats × rule modes, including both four-seat throw-in scopes), 15,398 audited actions, 0 failures, 22–101 steps under a 1,500-step bound. Evidence: `proofs/durak-stress-0.2.6.6.json`.
- **Browser/Vision:** Mobile setup/deal at `390×844`, and compact Durak lobby at `320×800` (tier headings clear of locks); iPad portrait `834×1194` transfer setup/live 52-card human defense; landscape `1194×834` throw-in setup and 36-card Off deal. The Transfer button was clicked in a rendered human-defense state and passed a physical-card audit. Vision verified the zero-talon/trump display and all setup/action labels. The compact 320px title padding and narrow `DEFEND`/Transfer text were refined. Physical Apple Safari was not available.
- **Static checks:** `deckforge.html` is 307,131 bytes / 2,289 lines, one inline script, 87 literal DOM refs; no missing/duplicate IDs, external assets/URLs, or inline event attributes. `node --check`, ten proof JSONs/ten PNG signatures, and `git diff --check` pass; details: `proofs/static-audit-0.2.6.6.json`.
- **Release artifacts:** `VERSION` / `APP_VERSION` `0.2.6.6`; notes `RELEASE_NOTES_0.2.6.6.md`; archive `releases/DeckForge-0.2.6.6.zip`; tag `v0.2.6.6`. Verify release, asset checksum, Pages build, live bytes, and clean worktree.

### DeckForge 0.2.6.7 — Mau-Mau and placement-based Durak settlement

- **Version:** Explicit target `0.2.6.7`, with `v0.2.6.6` preserved as the previous release.
- **Mau-Mau:** Added a physical-card 2–4-seat game with 32/36/52/64 packs, 5/6/7-card hands, configurable common/house rules, three scoring modes, calls, AI, bankroll/progression, rules help, and fixed-round Idioten-Mau. Rule disagreements and defaults are in `references/mau-mau-rules.md`.
- **Durak economy:** Track finisher order separately from the final Durak. First place wins the full pot; later finishers return only their own ante; last loses their ante; draws refund it. Only first place records progression. A settlement toast was removed because it obscured rematch buttons; opponent card-count copy is singular when appropriate.
- **Diagnostics:** `121/121` in-app tests, 0 failures and 0 browser errors. Durak stress: 360 matches / 30 configs / 15,430 audited actions; all terminated in 22–97 steps, including 49 draws. The 311 non-draw matches had complete unique finish orders with the final Durak last; 0 failures.
- **Manual flows:** Mau-Mau completed a 32-card two-seat UI match with Jack wish, Mau and Mau-Mau calls; human won with 32/32 cards audited. Durak completed a rendered 3-seat second-place result (`finishOrder [2,0,1]`); the `$10` ante returned, net `$0`, no win progression, 36/36 cards audited.
- **Responsive/Vision:** Active Mau-Mau table checked at 320×800, 390×844 and 1024×768. The real Idioten-Mau setup (18 advanced controls; 3/5/7 rounds) was opened and checked at 320×800, 390×844, 834×1194, 1024×768, 1194×834 and 1366×900; 0 label/button overflows and no document width exceeded its viewport. Durak second-place result checked at 390×844. Chromium emulation only; physical Apple Safari was not tested.
- **Static:** Runtime 423,139 bytes / 2,833 lines, one inline script, 58 unique IDs, 51 unique literal DOM references, no missing/duplicate IDs, external assets or runtime URLs. JSON/PNG validation, `node --check`, and `git diff --check` pass.
- **Release files:** `VERSION` / `APP_VERSION` `0.2.6.7`; `RELEASE_NOTES_0.2.6.7.md`; `releases/DeckForge-0.2.6.7.zip`; tag `v0.2.6.7`. Verify release asset, Pages deploy/build, live bytes, and clean worktree before handoff.

### Mau-Mau suit-wish resolution fix — included in 0.2.8.0

- **Bug:** after a Jack requested a suit, `wishSuit` stayed active even after a card of that suit was played. The next player was still restricted to the old suit and could not match the new top card by rank.
- **Fix:** a non-Jack Mau-Mau play consumes the old wish; a newly played Jack replaces it. Jack-on-Jack remains off by default, and the enabled UI path chooses the replacement wish.
- **Verification:** The v0.2.8.0 suite passes `144/144` at each of seven viewports, including engine and rendered UI regressions for wish fulfillment, alternate-suit rank matching, and enabled Jack-on-Jack; browser errors: 0.
- **Limit:** Physical iOS Safari was not tested.

### Home tile visual — Mau-Mau + UNO (0.2.8.0)

- **Tile:** Replaced the single heart icon with original local CSS art showing a Mau-Mau `J♥` and a four-color UNO-style `+2` card; title is `Mau-Mau + UNO`, and copy explicitly describes the optional 108-card deck. The whole tile remains the single launch button.
- **Route:** Clicking the tile still opens the Mau-Mau table; the UNO deck option is available in table setup.
- **Optical QA:** Built-in vision reviewed the current v0.2.8.0 Home rail at `390×844` with `Mau-Mau + UNO` selected and visible, plus responsive layouts at `320×700`, `1024×768`, `834×1194`, and `1194×834`. No clipping or horizontal overflow; screenshots are in `proofs/table-picker-carousel-0.2.8.0.json`.
- **Tests/static:** `144/144` tests pass at each of seven viewports, 0 browser errors; final runtime is 547,920 bytes / 3,373 lines with one inline script. Static evidence: `proofs/static-audit-0.2.8.0.json`.
- **Limit:** Chromium emulation only; physical iPhone/iPad Safari was not tested.

### Home game picker + independent Durak rules (0.2.8.0)

- **Home picker:** Added a scroll-snap game rail directly below the top bar for Blackjack, Durak, and Mau-Mau + UNO. It supports horizontal scrolling, keyboard selection, accessible selected state, and a separate Open action.
- **Spin:** Added a horizontal slot-style decelerating random picker. It never places a wager or starts a round; reduced-motion users get an immediate result. Navigation cancels pending spins.
- **Durak options:** Replaced the exclusive rule choice with independent Throw-in and Transfer On/Off controls. Existing defaults and saved `attackRule` choices migrate; Throw-in scope remains conditional and limited by seat count.
- **Verification:** `144/144` in-app tests pass at each of `320×700`, `320×800`, `390×844`, `834×1194`, `1194×834`, `1024×768`, and `1280×720`; no browser errors. UI settings, all four Durak combinations, persistence, no-wager spin/open behavior, reduced motion, cancellation, and card reachability are covered by `proofs/table-picker-carousel-0.2.8.0.json` and `proofs/durak-independent-rule-toggles-0.2.8.0.json`.
- **Touch limit:** Native scroll/snap selection synchronization is covered by tests. A foreground CUA scroll probe did not visibly move the rail; an earlier CDP touch attempt timed out. Physical iOS/Safari swipe remains unverified.

### DeckForge 0.2.8.0 release — 2026-11-25

- **Base:** `v0.2.6.7`; release tag target: `v0.2.8.0`.
- **Scope:** UNO deck/variants, Mau-Mau wish fix, Mau-Mau + UNO tile, independent Durak rules, adaptive card sizing, Home picker/Spin, and the redesigned responsive project page.
- **Verification:** `144/144` tests at each of seven viewports; Durak stress: 336 seeded matches / 42 configurations / 15,019 audited actions / 0 failures. Final static/runtime and page-link proofs are in `proofs/`.
- **Release files:** `VERSION`, `RELEASE_NOTES_0.2.8.0.md`, `index.html`, and `releases/DeckForge-0.2.8.0.zip` (plus the standalone HTML release asset).
- **Limit:** Physical iPhone/iPad Safari and a real-device touch swipe were not tested.
